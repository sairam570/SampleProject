package com.tml.AIP_POSITION_JDG_TRANS.service;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.tml.AIP_POSITION_JDG_TRANS.esb.VORUIResponse;

@Component
public interface VORUIService {
	
	 List<VORUIResponse> findByOrderId(String OrderId);
		public List<Map> getVORUIListAsListOfMap(List<VORUIResponse> vorUIResponseList);

}
