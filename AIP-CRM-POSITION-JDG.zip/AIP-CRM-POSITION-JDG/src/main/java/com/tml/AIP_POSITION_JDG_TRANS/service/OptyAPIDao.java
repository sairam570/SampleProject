package com.tml.AIP_POSITION_JDG_TRANS.service;

public interface OptyAPIDao {
	//public Map<String, Object> CheckDuplicateOpty(Map<String, String> map);
}
