package com.tml.AIP_POSITION_JDG_TRANS.service;

import java.lang.reflect.Constructor;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.hibernate.query.Query;
import org.hibernate.sql.Template;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.infinispan.client.hotrod.RemoteCache;
import org.infinispan.client.hotrod.RemoteCacheManager;
import org.infinispan.commons.api.CacheContainerAdmin;
import org.infinispan.commons.api.CacheContainerAdmin.AdminFlag;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.google.gson.Gson;
import com.tml.AIP_POSITION_JDG_TRANS.esb.StudentDetails;

@Repository
@Transactional
public class OptyAPIDaoImpl implements OptyAPIDao {
	// private static final Logger logger =
	// LoggerFactory.getLogger(OptyAPIDaoImpl.class);
	@Autowired
	RemoteCacheManager cacheManager;
	
	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<StudentDetails> CheckDuplicateOpty() {
	// public List<Object[]> CheckDuplicateOpty() {
		Session session = sessionFactory.getCurrentSession();
		try {
		//String query_string = "SELECT ud.user_id as user_Id,ud.user_name as user_Name,ud.email_id as email_Id,ud.mobile_no as mobile_No,l.lab_name as lab_Name,b.book_name as book_Name,b.author as author,b.price as price from user_details ud INNER JOIN lab_details l on ud.user_id = l.user_id INNER JOIN books_details b on l.lab_id = b.lab_id";
		
		String query_string = "SELECT ud.user_id,ud.user_name,ud.email_id,ud.mobile_no,l.lab_name,b.book_name,b.author,b.price from user_details ud INNER JOIN lab_details l on ud.user_id = l.user_id INNER JOIN books_details b on l.lab_id = b.lab_id";
		Query query = session.createNativeQuery(query_string).setResultTransformer(Transformers.aliasToBean(StudentDetails.class));
		//query.setResultTransformer(Transformers.aliasToBean(StudentDetails.class));
		
		// NativeQuery<Object[]> queryObj = session.createNativeQuery(query_string);
		
		 return query.list();
		// return queryObj.getResultList();
		
		}catch (Exception e) {
			throw e;
		}
		
	}

	// @Scheduled(fixedRate = 1000)
	 @Scheduled(cron = "0 0 13 * * *")
	// @Scheduled(cron = "*/60 * * * * *")
	 
	   public void cronJobSch() {
		//System.out.println("----This is Sai-------");
		String cacheName = "Sample";
		cacheManager.start();
		// Create cache
		
	//	cacheManager.administration().withFlags(AdminFlag.VOLATILE).getOrCreateCache(cacheName, "default");
	//	cacheManager.administration().createCache(cacheName, "default");
		
		//  cacheManager.administration().withFlags(CacheContainerAdmin.AdminFlag.PERMANENT).getOrCreateCache(cacheName, DefaultTemplate.LOCAL);
		 
		// Obtain the remote cache
		RemoteCache<String, String> cache = cacheManager.getCache(cacheName);
		
	    //List<Books> books =  booksService.getAllBooks();
		//List<StudentDetails> details = booksService.getStudentDetails();
		
		List<StudentDetails> details = CheckDuplicateOpty();
		for (StudentDetails detail : details) {
			System.out.println(detail.toString());

			cache.put(String.valueOf(detail.getUser_id()), new Gson().toJson(detail));
		}
		
		cacheManager.stop();
		
	}
	
}
